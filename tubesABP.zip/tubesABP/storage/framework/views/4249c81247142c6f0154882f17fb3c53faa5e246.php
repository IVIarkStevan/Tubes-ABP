

<?php $__env->startSection('container'); ?>
    <h1>Perkemahan</h1>

    <div class="card-group">
        <?php $__currentLoopData = $perkemahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kemah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="mb-5">
                <div class="card" style="width: 18rem;">
                    <img src="<?php echo e($kemah->image1); ?>" class="card-img-top" alt="<?php echo e($kemah["image"]); ?>" width="150" height="150">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($kemah->title); ?></h5>
                        <p class="card-text"><?php echo e($kemah->excerpt); ?></p>
                        <a href="/perkemahan/<?php echo e($kemah->slug); ?>" class="btn btn-primary">Selengkapnya</a>
                    </div>
                </div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DHIALIF\Program\Laravel-Projects\tubesABP\resources\views/perkemahan.blade.php ENDPATH**/ ?>