

<?php $__env->startSection('container'); ?>
    <div class="container">
        <div id="carousel_img" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carousel_img" data-bs-slide-to="0" aria-label="Slide 1" class="active" aria-current="true" ></button>
                <button type="button" data-bs-target="#carousel_img" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carousel_img" data-bs-slide-to="2" aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="<?php echo e($kemah->image1); ?>" class="d-block w-100" alt="image1">
                
            </div>
            <div class="carousel-item">
                <img src="<?php echo e($kemah->image2); ?>" class="d-block w-100" alt="image2">
            </div>
            <div class="carousel-item">
                <img src="<?php echo e($kemah->image3); ?>" class="d-block w-100" alt="image3">
            </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carousel_img" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carousel_img" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>

    <article>
        
        <h2><?php echo e($kemah->title); ?></h2>
        <div>
            <h5>Deskripsi : </h5>
            <p><?php echo e($kemah->description); ?>.</p>
        </div>
        <div>
            <h5>Alamat :</h5>
            <p><?php echo e($kemah->alamat); ?></p>
        </div>
        <div>
            <h5>Harga :</h5>
            <p><?php echo e($kemah->harga); ?></p>
        </div>
        <div>
            <h5>Fasilitas :</h5>
            <p><?php echo e($kemah->fasilitas); ?></p>
        </div>
        <div>
            <h5>Website :</h5>
            <p><a href="<?php echo e($kemah->website); ?>"><?php echo e($kemah->website); ?></a></p>
        </div>
        <div>
            <h5>Contact :</h5>
            <p><?php echo e($kemah->contact); ?></p>
        </div>
    </article>

    <a href="/perkemahan">Back to Perkemahan</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DHIALIF\Program\Laravel-Projects\tubesABP\resources\views/kemah.blade.php ENDPATH**/ ?>