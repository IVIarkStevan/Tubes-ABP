@extends('layouts.main')

@section('container')
    <h1>Selamat Datang!</h1>
@endsection