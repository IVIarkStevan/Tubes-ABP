<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rancaupas</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="rancaupas">
            <img src="/img/rancaupas/ranca1.jpg" alt="rusak"/>
            <div class="nama">Ranca Upas</div>
            <div class="abaout">Ranca Upas atau Kampung Cai Ranca Upas adalah salah satu bumi perkemahan di Bandung, Jawa Barat, Indonesia. Terletak di Jalan Raya Ciwidey Patenggang KM. 11, Alam Endah, Ciwidey Kabupaten Bandung, dengan jarak sekitar 50 km dari pusat Kota Bandung</div>
            <div class="alamat">Alamat: Jl. Raya Ciwidey - Patengan No.KM. 11, Patengan, Kec. Rancabali, Kabupaten Bandung, Jawa Barat 40973</div>
            <div class="link">
                <a href="https://www.instagram.com/ranca_upas/">
                    <img src="img/sosialmedia/instagram.png" />
        </div>
    </div>
</body>
</html>