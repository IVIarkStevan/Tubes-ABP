<div class="card-group">
    @foreach ($perkemahan as $arrKemah)
        <div class="card" style="width: 18rem;">
            <img src="{{ $kemah["image"] }}" class="card-img-top" alt="..." width="150" height="150">>
            <div class="card-body">
                <h5 class="card-title">{{ $kemah["title"] }}</h5>
                <p class="card-text">{{ $kemah["description"] }}</p>
                <a href="{{ $kemah["route"] }}" class="btn btn-primary">Selengkapnya</a>
            </div>
        </div>
    @endforeach
</div>