<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />
        <link rel="stylesheet" href="style.css">
    <title>Perkemahan</title>
</head>

<body>
    <div class="alert alert-danger alert-dismissible fade show text-center" role="alert">
        <strong>ALERT!</strong> This page is Belom Jadi.
        <button type="button" class="btn-close btn-dark" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    <div class="container">
        <section>
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <div class="container">
                    <a class="navbar-brand" href="#">Perkemahan</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false"
                        aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                        <div class="navbar-nav">
                            <a class="nav-link active" aria-current="page" href="index.html">Home</a>
                            <a class="nav-link" href="perkemahan.html">perkemahan</a>
                            <a class="nav-link" href="resevasi.html">Reservasi</a>
                        </div>
                    </div>
                </div>
            </nav>
        </section>
        <section>
            <h2 class="mt-3">Perkemahan</h2>
            <div class="card-group">
                <div class="card">
                    <img src="rancaupas/ranca1.jpg" class="card-img-top" alt="..." width="150" height="150">
                    <div class="card-body">
                        <h5 class="card-title">Ranca Upas</h5>
                        <p class="card-text">Ranca Upas atau Kampung Cai Ranca Upas adalah salah satu bumi perkemahan di Bandung, Jawa Barat, Indonesia.</p>
                        <a href="rancaupas.html " class="btn btn-primary">Selengkapnya</a>
                    </div>
                </div>
                <div class="card">
                    <img src="dusunbambu/dusun1.jpg" class="card-img-top" alt="..." width="150" height="150">
                    <div class="card-body">
                        <h5 class="card-title">Dusun Bambu</h5>
                        <p class="card-text">Tempat wisata yang berada di Bandung Utara ini selain indah tempat ini juga memiliki udara yang sejuk dan juga sangat segar.</p>
                        <a href="dusunbambu.html" class="btn btn-primary">Selengkapnya</a>
                    </div>
                </div>
                <div class="card">
                    <img src="maribaya/mari1.jpg" class="card-img-top" alt="..." width="150" height="150">
                    <div class="card-body">
                        <h5 class="card-title">The Lodge Maribaya</h5>
                        <p class="card-text">The Lodge Maribaya dibangun untuk menciptakan wisata alam dengan udara yang sejuk dan bebas polusi di area pengunungan hutan pinus maribaya.</p>
                        <a href="maribaya.html" class="btn btn-primary">Selengkapnya</a>
                    </div>
                </div>
                <div class="card">
                    <img src="" class="card-img-top" alt="..." width="150" height="150">
                    <div class="card-body">
                        <h5 class="card-title"></h5>
                        <p class="card-text"></p>
                        <a href="#" class="btn btn-primary"></a>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="alert alert-dark mt-3 text-center" role="alert">
                Ini Footer
            </div>
        </section>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
</body>

</html>